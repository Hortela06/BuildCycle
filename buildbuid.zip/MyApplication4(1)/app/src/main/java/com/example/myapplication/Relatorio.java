package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class Relatorio extends AppCompatActivity {
    //medidas
    static double tamanhoMTB;
    static double tamanhoSpeed;
    static double alturaSelim;
    static double tamanhoTop;
    //componentes
    static String velocidades;
    static String transmissao;
    static String freios;
    static String suspensao;

    static String[] componentes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relatorio);
        getSupportActionBar().hide();
        carregaComponentes();
        //System.out.println(tamanhoTop);

        TextView tamanhoQuadro = (TextView)findViewById(R.id.quadro);
        if(tamanhoMTB == 0){
            tamanhoQuadro.setText(tamanhoSpeed+"");
            Toast.makeText(Relatorio.this, tamanhoSpeed+"", Toast.LENGTH_LONG).show();
        }else{
            tamanhoQuadro.setText(tamanhoMTB+"");
        }

        TextView selim = (TextView)findViewById(R.id.selim);
        selim.setText(alturaSelim+"");

        TextView mesa = (TextView)findViewById(R.id.mesa);
        mesa.setText(tamanhoTop+"");

        TextView marchas = (TextView)findViewById(R.id.marchas);
        marchas.setText(componentes[0]+"");

        TextView grupo = (TextView)findViewById(R.id.transmissao);
        grupo.setText(componentes[1]+"");

        TextView freio = (TextView)findViewById(R.id.freio);
        freio.setText(componentes[2]+"");

        TextView garfo = (TextView)findViewById(R.id.garfo);
        garfo.setText(componentes[3]+"");


    }
    public void carregaComponentes(){
        componentes = Componentes.Calculo();
    }
}